#!/bin/sh
$PYTHON setup.py install
