#### A small, complete example of the issue

```python
# Your code here

```

#### Expected Output

#### Output of ``pd.show_versions()``

<details>
# Paste the output here

</details>
